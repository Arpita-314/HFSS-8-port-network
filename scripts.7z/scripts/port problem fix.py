# ----------------------------------------------
# Script Recorded by Ansys Electronics Desktop Version 2023.1.0
# 15:58:37  Sep 08, 2024
# ----------------------------------------------
import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
