# ----------------------------------------------
# Script Recorded by Ansys Electronics Desktop Student Version 2023.2.0
# 15:46:20  Jul 02, 2024
# ----------------------------------------------
import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
