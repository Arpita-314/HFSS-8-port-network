# ----------------------------------------------
# Script Recorded by Ansys Electronics Desktop Student Version 2023.2.0
# 20:34:09  Jul 03, 2024
# ----------------------------------------------
import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.SetActiveProject("Project4")
oProject.Save()
